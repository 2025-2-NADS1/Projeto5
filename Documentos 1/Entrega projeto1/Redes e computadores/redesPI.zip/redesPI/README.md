Objetivo: Testar comandos que serão futuramente utilizados no projeto.

Comandos: GET FOOD(retorna que o pet foi alimentado e passa um dia);
GET DAY(descreve em que dia estamos);
GET HAPPY(retorna o estado do pet entre felicidade e tristeza).

Arquivo principal: pasta piForms.