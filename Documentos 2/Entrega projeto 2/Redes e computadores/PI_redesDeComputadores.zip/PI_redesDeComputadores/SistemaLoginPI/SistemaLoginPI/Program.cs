﻿using System;
using System.IO;
using System.Linq;

class Program
{
    // Arquivo com extensão .db
    static string arquivo = "usuarios.db";

    static void Main()
    {
        // Cria o arquivo se não existir
        if (!File.Exists(arquivo))
            File.Create(arquivo).Close();

        while (true)
        {
            Console.WriteLine("Escolha: 1-Cadastrar 2-Login 3-Sair");
            string opcao = Console.ReadLine();

            if (opcao == "1")
                Cadastrar();
            else if (opcao == "2")
                Login();
            else if (opcao == "3")
                break;
        }
    }

    static void Cadastrar()
    {
        Console.Write("Usuário: ");
        string usuario = Console.ReadLine();
        Console.Write("Senha: ");
        string senha = Console.ReadLine();

        var linhas = File.ReadAllLines(arquivo);
        if (linhas.Any(l => l.Split(':')[0] == usuario))
        {
            Console.WriteLine("Usuário já existe!");
            return;
        }

        File.AppendAllText(arquivo, $"{usuario}:{senha}\n");
        Console.WriteLine("Usuário cadastrado!");
    }

    static void Login()
    {
        Console.Write("Usuário: ");
        string usuario = Console.ReadLine();
        Console.Write("Senha: ");
        string senha = Console.ReadLine();

        var linhas = File.ReadAllLines(arquivo);
        if (linhas.Any(l => l == $"{usuario}:{senha}"))
            Console.WriteLine("Login realizado com sucesso!");
        else
            Console.WriteLine("Usuário ou senha incorretos.");
    }
}
